#include<iostream>
using namespace std;

int main(){
	int physics = 84;
	int maths = 94;
	int chemistry = 87;
	cout<<"physics = "<<physics<<"\nchemistry = "<<chemistry<<"\nmath = "<<maths;
	
	return 0;
}
