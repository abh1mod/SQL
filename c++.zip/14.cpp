#include<iostream>
using namespace std;

float calculate(float a,float b, char ch){
	float ans = 0;
	switch(ch){
	case '+': ans = a+b;
	    break;
	case '-': ans = a-b;
            break;
        case '/': 
        	if(b==0) cout<<"Enter Non Zero Denominator";
        	else ans = a/b;
            break;
        case '*':
        	ans = a*b;
            break;
        default:
        	cout<<"Enter Valid Operator";
	}
	return ans;
}

int main(){
	float a,b;
	char op;
	cout<<"Enter operands ";
	cin>>a>>b;
	cout<<"Enter operator(+,-,/,*) : ";
	cin>>op;
	cout<<calculate(a,b,op)<<endl;
	
}
