#include<iostream>
using namespace std;

int main(){
	int a,b;
	cout<<"Enter two Num ";
	cin>>a>>b;
	if(a>=b) cout<<a<<"is Larger";
	else cout<<b<<" is larger";
	return 0;
}
