#include<iostream>
using namespace std;
class Marks{
     private :
	int sub1;
	int sub2;
     public:
     	void insertMarks(){
     	    cout<<"Enter marks of subject 1 and 2 : ";
     	    cin>>sub1>>sub2;
     	}
     	void displayMarks(){
     	    cout<<"Subject1 = "<<sub1<<endl;
     	    cout<<"Subject2 = "<<sub2<<endl;
     	}
	
};
int main(){
	Marks student1;
	student1.insertMarks();
	student1.displayMarks();
	return 0;
}
