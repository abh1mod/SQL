#include <iostream>
#include <stack>
#include <string>
using namespace std;

int result(int a,int b, char op){
	int ans;
	if(op=='+') ans = a+b;
	else if(op=='-') ans = a-b;
	else if(op=='*') ans = a*b;
	else if(op=='/') ans = a/b;
	return ans;
}


int evaluatePrefix(string s) {
    stack<int> st;   
    for(int i = s.length()-1; i >=0; i--) {
    	char ch = s[i];
        if (isdigit(ch)){
            st.push(ch - '0');
        } 
        else if (ch == '+' || ch == '-' || ch == '*' || ch == '/') {
            int op1 = st.top();
            st.pop();
            int op2 = st.top();
            st.pop(); 
            int ans = result(op1,op2,ch);    
            st.push(ans);
        }
    }
    return st.top();
}

int main() {
    string s; 
    cout<<"Enter a prefix expression :";
    cin>>s;
    cout << "Result of Prefix Evaluation: " << evaluatePrefix(s) << endl;
    return 0;
}


