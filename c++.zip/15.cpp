#include<iostream>
#include<math.h>
using namespace std;

bool prime(int n){
	bool isPrime = 1;
	if(n<=1) isPrime = 0;
	if(n==2) isPrime = 1;
	for(int i = 2; i<=sqrt(n); i++){
		if(n%i==0){
		  isPrime = 0;
		  break;
		}
	}
	return isPrime;
}
int main(){
	int n;
	cout<<"Enter a Number ";
	cin>>n;
	if(prime(n)) cout<<n<<" is Prime Number";
	else cout<<n<<" is NonPrime Number";	
	return 0;
}
