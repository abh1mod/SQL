#include<iostream>
using namespace std;

int main(){
	int n,ans=1;
	cout<<"Enter Number ";
	cin>>n;
	for(int i =1; i<=n; i++){
	    ans *= i;
	}
	cout<<"Factorial of "<<n<<" : "<<ans;
	return 0;
}
