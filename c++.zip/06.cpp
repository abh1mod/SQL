#include<iostream>
using namespace std;

int maximum(int a,int b){
	if(a>=b) return a;
	else return b;
}
int main(){
	int a,b,c;
	cout<<"Enter 3 Numbers ";
	cin>>a>>b>>c;
	int ans = maximum(a,maximum(b,c));
	cout<<"Largest among 3 "<<ans;
	
	return 0;
}
