#include<iostream>
using namespace std;

void matrix(int m,int n){
	int arr[m][n];
	cout<<"Enter Elements of Matrix:"<<endl;
	for(int i = 0; i<m; i++){
	    for(int j = 0; j<n; j++) cin>>arr[i][j];
	}
	cout<<"Matrix Created by user:"<<endl;
	for(int i = 0; i<m; i++){
	    for(int j = 0; j<n; j++) cout<<arr[i][j]<<" ";
	    cout<<endl;
	}
}

int main(){
	int m,n;
	cout<<"Enter size of Row and Coloumn :";
	cin>>m>>n;
	matrix(m,n);
	return 0;
}
