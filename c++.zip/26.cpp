#include<iostream>
#include<math.h>
using namespace std;
class account{
     int bal;
     float rate;
     public:
        account(){
           cout<<"Enter balance and rate of Interest : ";
           cin>>bal>>rate;
        }
        void deposit(){
            int b;
            cout<<"Enter Amount to Deposit : ";
            cin>>b;
            bal += b;
            cout<<"Amount Deposited"<<endl;
        }
        void withdraw(){
            int w;
            cout<<"Enter Amount to withdraw : ";
            cin>>w;
            if(w>bal){
             	cout<<"Insufficeint Balance "<<endl;
             	return;
            }
            bal -= w;
            cout<<"Amount Withdrawn"<<endl;
        }
        void check(){
            cout<<"Current Balance : "<<bal<<endl;
        }
        void compInt(){
            int n;
            cout<<"Enter Time Period : ";
            cin>>n;
            float ci = bal*pow(1+(rate/100),n);
            cout<<"Compund Interest : "<<ci - bal<<endl;
            bal = ci;
        }
        ~account(){}
       
};
int main(){
    account a;
    int x;
    while(x!=5){
       cout<<"Enter Choice : "<<endl;
       cout<<"Enter 1 to Check Balance "<<endl;
       cout<<"Enter 2 to Withdraw Balance "<<endl;
       cout<<"Enter 3 to Deposit Balance "<<endl;
       cout<<"Enter 4 to Calculate Compund Interest "<<endl;
       cout<<"Enter 5 to Terminate "<<endl;
       cin>>x;
       cout<<"-------------------------"<<endl;
       switch(x){
          case 1: a.check(); break;
          case 2: a.withdraw(); a.check(); break;
          case 3: a.deposit(); a.check(); break;
          case 4: a.compInt(); a.check(); break;
          case 5: break;
          default: cout<<"Enter Valid Choice "<<endl;
       }
       cout<<"-------------------------"<<endl;
    }
    return 0;
}
