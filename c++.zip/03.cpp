#include<iostream>
using namespace std;

int main(){
	int a,b,c;
	cout<<"Enter value of a,b,c ";
	cin>>a>>b>>c;
	if(b==c) cout<<"Division by Zero";
	else{
		float x = a/(float)(b-c);
		cout<<"a/(b-c) = "<<x;
	}
	
	return 0;
}

/*a/b-c
factorial
swap
largest 3
natural num
multipl table
fibo
*/
