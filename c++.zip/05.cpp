#include<iostream>
using namespace std;

int main(){
	int a,b;
	cout<<"Enter two Num ";
	cin>>a>>b;
	a=a+b;
	b=a-b;
	a=a-b;
	cout<<"swaped num "<<a<<" "<<b;
		
	return 0;
}
