#include<iostream>
using namespace std;
class Node{
    public:
    int data;
    Node* next;
       Node(int val){
          data = val;
       }
};
class Queue{
    Node* front;
    Node* back;
    public:
      Queue(){
        front = nullptr;
        back = nullptr;
      }
      bool isEmpty(){
        return (front==nullptr);
      }
      void enqueue(int val){
         Node* temp = new Node(val);
         if(isEmpty()) {
            front = temp;
            back = temp;
         }
         else{
            back->next = temp;
            back = back->next;
         }
      }
      void dequeue(){
         if(isEmpty()){
           cout<<"Queue Underflow"<<endl;
           return;
         }
         else if(front->next==nullptr){
            front = nullptr;
            back = nullptr;
         }
         else{
            Node* temp = front;
            front = front->next;
            delete temp;
         }
      }
      int peek(){
         if(isEmpty()) return -1;
         return this->front->data;
      }
};
int main(){
    Queue q;
    int x;
   
    while(x!=5){
       cout<<"Enter Choice : "<<endl;
       cout<<"Enter 1 to Enqueue "<<endl;
       cout<<"Enter 2 to Dequeue "<<endl;
       cout<<"Enter 3 to Peek "<<endl;
       cout<<"Enter 4 to Check if Empty "<<endl;
       cout<<"Enter 5 to Terminate "<<endl;
       cin>>x;
       switch(x){
          case 1: int a; cout<<"Enter Element : "; cin>> a; q.enqueue(a); break;
          case 2: q.dequeue(); break;
          case 3: cout<<q.peek(); break;
          case 4: cout<<q.isEmpty(); break;
          case 5: break;
          default: cout<<"Enter Valid Choice "<<endl;
       }
       cout<<endl;
      
    }
    return 0;
}
