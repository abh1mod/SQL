#include<iostream>
using namespace std;
class Node{
    public:
    int data;
    Node* next;
       Node(int val){
          data = val;
       }
};
class Stack{
    Node* head;
    public:
      Stack(){
        head = nullptr;
      }
      bool isEmpty(){
        return (head==nullptr);
      }
      void push(int val){
         Node* temp = new Node(val);
         if(isEmpty()) head = temp;
         else{
            temp->next = head;
            head = temp;
         }
      }
      void pop(){
         if(isEmpty()){
           cout<<"Stack Underflow"<<endl;
           return;
         }
         else{
            Node* temp = head;
            head = head->next;
            delete temp;
         }
      }
      int top(){
         if(isEmpty()) return -1;
         return this->head->data;
      }
};
int main(){
    Stack st;
    int x;
   
    while(x!=5){
       cout<<"Enter Choice : "<<endl;
       cout<<"Enter 1 to Push "<<endl;
       cout<<"Enter 2 to Pop "<<endl;
       cout<<"Enter 3 to Top "<<endl;
       cout<<"Enter 4 to Check if Empty "<<endl;
       cout<<"Enter 5 to Terminate "<<endl;
       cin>>x;
       switch(x){
          case 1: int a; cout<<"Enter Element : "; cin>> a; st.push(a); break;
          case 2: st.pop(); break;
          case 3: cout<<st.top(); break;
          case 4: cout<<st.isEmpty(); break;
          case 5: break;
          default: cout<<"Enter Valid Choice "<<endl;
       }
       cout<<endl;
      
    }
    return 0;
}
