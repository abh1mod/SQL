#include <iostream>
using namespace std;

class student{
   protected:
      int roll_no;
   public:
      void get_roll(){
        cout<<"Enter Roll Num ";
        cin>>roll_no;
      }
      void print_roll(){
         cout<<roll_no<<endl;
      }
};
class marks: public student{
   protected:
     int m1;
     int m2;
   public:
     void get_marks(){
       cout<<"Enter Marks of sub1 and sub2 ";
       cin>>m1>>m2;
     }
     void print_mark(){
        cout<<m1<<" "<<m2<<endl;
     }
};
class result:public marks{
    public: 
      int res;
      void print_result(){
      	res = m1+m2;
        cout<<res<<endl;
      }  
};

int main(){
   result s1;
   s1.get_roll();
   s1.get_marks();
   s1.print_roll();
   s1.print_mark();
   s1.print_result();
   
}
